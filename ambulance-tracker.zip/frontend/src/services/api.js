const API_URL = 'http://localhost:3000/api';

export async function login(username, password) {
  const res = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) throw new Error('Login failed');
  return res.json();
}

export async function register(fullName, username, password, address, phone) {
  const res = await fetch(`${API_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fullName, username, password, address, phone })
  });
  if (!res.ok) throw new Error('Registration failed');
  return res.json();
}

export async function fetchComments() {
  const res = await fetch(`${API_URL}/comments`);
  if (!res.ok) throw new Error('Failed to fetch comments');
  return res.json();
}

export async function postComment(userId, content, parentId = null) {
  const res = await fetch(`${API_URL}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, content, parentId })
  });
  if (!res.ok) throw new Error('Failed to post comment');
  return res.json();
}

export async function getAmbulanceLocation() {
  const res = await fetch(`${API_URL}/ambulance`);
  if (!res.ok) throw new Error('Failed to get ambulance location');
  return res.json();
}

export async function updateAmbulanceLocation(latitude, longitude) {
  const res = await fetch(`${API_URL}/ambulance`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ latitude, longitude })
  });
  if (!res.ok) throw new Error('Failed to update location');
  return res.json();
}
