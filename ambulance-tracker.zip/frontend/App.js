import React, { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LoginScreen from './src/screens/LoginScreen';
import RegisterScreen from './src/screens/RegisterScreen';
import MainScreen from './src/screens/MainScreen';
import AdminScreen from './src/screens/AdminScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('main');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [username, setUsername] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const userId = await AsyncStorage.getItem('userId');
        const storedUsername = await AsyncStorage.getItem('username');
        const storedIsAdmin = await AsyncStorage.getItem('isAdmin');
        if (userId && storedUsername) {
          setIsLoggedIn(true);
          setUsername(storedUsername);
          setIsAdmin(storedIsAdmin === 'true');
          setCurrentScreen(storedIsAdmin === 'true' ? 'admin' : 'main');
        }
      } catch (error) {
        console.error('Failed to load user data', error);
      }
    })();
  }, []);

  const handleLogin = async (user) => {
    await AsyncStorage.setItem('userId', user.id.toString());
    await AsyncStorage.setItem('username', user.username);
    await AsyncStorage.setItem('isAdmin', user.isAdmin ? 'true' : 'false');
    setIsLoggedIn(true);
    setIsAdmin(user.isAdmin);
    setUsername(user.username);
    setCurrentScreen(user.isAdmin ? 'admin' : 'main');
  };

  const handleRegister = async (user) => {
    await AsyncStorage.setItem('userId', user.id.toString());
    await AsyncStorage.setItem('username', user.username);
    await AsyncStorage.setItem('isAdmin', 'false');
    setIsLoggedIn(true);
    setIsAdmin(false);
    setUsername(user.username);
    setCurrentScreen('main');
  };

  const handleLogout = async () => {
    await AsyncStorage.clear();
    setIsLoggedIn(false);
    setIsAdmin(false);
    setUsername('');
    setCurrentScreen('main');
  };

  switch (currentScreen) {
    case 'login':
      return (
        <LoginScreen
          onLogin={handleLogin}
          onNavigateRegister={() => setCurrentScreen('register')}
          onBack={() => setCurrentScreen('main')}
        />
      );
    case 'register':
      return (
        <RegisterScreen
          onRegister={handleRegister}
          onNavigateLogin={() => setCurrentScreen('login')}
          onBack={() => setCurrentScreen('main')}
        />
      );
    case 'admin':
      return (
        <AdminScreen
          isAdmin={isAdmin}
          onBack={() => setCurrentScreen('main')}
        />
      );
    default:
      return (
        <MainScreen
          isLoggedIn={isLoggedIn}
          isAdmin={isAdmin}
          username={username}
          onLogout={handleLogout}
          onAdmin={() => setCurrentScreen('admin')}
        />
      );
  }
}
