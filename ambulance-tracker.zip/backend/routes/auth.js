const express = require('express');
const router = express.Router();
const db = require('../database');

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const { username, password, fullName, address, phone } = req.body;
  if (!username || !password || !fullName || !address || !phone) {
    return res.status(400).json({ error: 'All fields are required' });
  }
  try {
    const [rows] = await db.query('SELECT id FROM users WHERE username = ? LIMIT 1', [username]);
    if (rows.length > 0) {
      return res.status(400).json({ error: 'Username already exists' });
    }
    const [result] = await db.query(
      'INSERT INTO users (username, password, fullName, address, phone, isAdmin) VALUES (?, ?, ?, ?, ?, 0)',
      [username, password, fullName, address, phone]
    );
    res.json({ id: result.insertId, username });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  if (username === 'ppidkotamadiun' && password === 'madiunmajujayasentosa') {
    return res.json({ id: 0, username, isAdmin: true });
  }
  try {
    const [rows] = await db.query('SELECT id, username, password, isAdmin FROM users WHERE username = ? LIMIT 1', [username]);
    if (rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    const user = rows[0];
    if (user.password !== password) {
      return res.status(401).json({ error: 'Incorrect password' });
    }
    res.json({ id: user.id, username: user.username, isAdmin: user.isAdmin === 1 });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

module.exports = router;
